import { useState } from 'react';
import CuratorPanel from './components/CuratorPanel';
import Player from './components/Player';
import KnowledgeManager from './components/KnowledgeManager';
import './App.css';

type Tab = 'curator' | 'knowledge';

function App() {
  const [activeTab, setActiveTab] = useState<Tab>('curator');

  return (
    <div className="app">
      <header className="app-header">
        <h1>灵境·AI 数字讲解系统</h1>
        <p>基于本地 LLM 的智能策展与自动化讲解</p>
        
        <nav className="tab-nav">
          <button 
            className={activeTab === 'curator' ? 'active' : ''}
            onClick={() => setActiveTab('curator')}
          >
            🎨 策展与播放
          </button>
          <button 
            className={activeTab === 'knowledge' ? 'active' : ''}
            onClick={() => setActiveTab('knowledge')}
          >
            📚 知识库管理
          </button>
        </nav>
      </header>

      <main className="app-main">
        {activeTab === 'curator' ? (
          <>
            <div className="left-panel">
              <CuratorPanel />
            </div>
            <div className="right-panel">
              <Player />
            </div>
          </>
        ) : (
          <div className="full-panel">
            <KnowledgeManager />
          </div>
        )}
      </main>
    </div>
  );
}

export default App;
