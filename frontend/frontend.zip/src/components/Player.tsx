import { usePlayerStore } from '../store/playerStore';

export default function Player() {
  const {
    script,
    currentPageIndex,
    isPlaying,
    state,
    progress,
    play,
    pause,
    next,
    prev,
    setProgress,
  } = usePlayerStore();

  if (!script) {
    return (
      <div className="player">
        <div className="empty-state">
          <h3>📝 暂无脚本</h3>
          <p>请先在左侧生成讲解脚本</p>
        </div>
      </div>
    );
  }

  const currentPage = script.timeline[currentPageIndex];
  const totalPages = script.timeline.length;

  return (
    <div className="player">
      <div className="player-header">
        <h2>🎙️ 播放器</h2>
        <span className="page-indicator">
          {currentPageIndex + 1} / {totalPages}
        </span>
      </div>

      <div className="script-display">
        <h3>{script.meta.title} - 第 {currentPageIndex + 1} 页</h3>
        <p className="content">{currentPage.voice_text}</p>
        <div className="duration">
          预计时长: {Math.round(currentPage.duration_ms / 1000)} 秒
        </div>
      </div>

      <div className="progress-bar">
        <input
          type="range"
          min="0"
          max="100"
          value={progress}
          onChange={(e) => setProgress(Number(e.target.value))}
          disabled={!isPlaying}
        />
        <span className="progress-text">{Math.round(progress)}%</span>
      </div>

      <div className="player-controls">
        <button
          onClick={prev}
          disabled={currentPageIndex === 0 || state === 'loading'}
          className="control-btn"
        >
          ⏮️ 上一页
        </button>

        <button
          onClick={isPlaying ? pause : play}
          disabled={state === 'loading'}
          className="control-btn play-btn"
        >
          {state === 'loading'
            ? '⏳ 加载中...'
            : isPlaying
            ? '⏸️ 暂停'
            : '▶️ 播放'}
        </button>

        <button
          onClick={next}
          disabled={currentPageIndex === totalPages - 1 || state === 'loading'}
          className="control-btn"
        >
          下一页 ⏭️
        </button>
      </div>

      {state === 'error' && (
        <div className="error-message">
          ⚠️ 播放出错，请重试
        </div>
      )}
    </div>
  );
}
