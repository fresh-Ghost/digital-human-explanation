import { useState, useEffect, useRef } from 'react';
import { api } from '../api';
import { usePlayerStore } from '../store/playerStore';
import { Voice, KnowledgeBase, ChatMessage } from '../types';
import { FaMicrophone, FaStop, FaMagic, FaCommentDots, FaTrash } from 'react-icons/fa';
import { encodeWAV } from '../utils/wavEncoder';

export default function CuratorPanel() {
  const [audience, setAudience] = useState('技术经理');
  const [duration, setDuration] = useState(5);
  const [message, setMessage] = useState('');
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(false);
  const [voiceId, setVoiceId] = useState('zh-CN-YunxiNeural');
  const [voices, setVoices] = useState<Voice[]>([]);
  const [knowledgeBases, setKnowledgeBases] = useState<KnowledgeBase[]>([]);
  
  // 录音相关状态
  const [isRecording, setIsRecording] = useState(false);
  const [isPlayingAudio, setIsPlayingAudio] = useState(false);
  const audioContextRef = useRef<AudioContext | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const processorRef = useRef<ScriptProcessorNode | null>(null);
  const samplesRef = useRef<Float32Array[]>([]);
  const audioPlayerRef = useRef<HTMLAudioElement | null>(null);
  const chatEndRef = useRef<HTMLDivElement | null>(null);

  const setScript = usePlayerStore((state) => state.setScript);

  // 自动滚动到底部
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // 加载语音列表和知识库列表
  useEffect(() => {
    loadVoices();
    loadKnowledgeBases();
  }, []);

  const loadVoices = async () => {
    try {
      const response = await api.getVoicesList();
      setVoices(response.data.voices || []);
    } catch (error) {
      console.error('加载语音列表失败:', error);
    }
  };

  const loadKnowledgeBases = async () => {
    try {
      const response = await api.getKnowledgeBasesList();
      setKnowledgeBases(response.data.knowledge_bases || []);
    } catch (error) {
      console.error('加载知识库列表失败:', error);
    }
  };

  const handleSwitchKnowledgeBase = async (kbId: string) => {
    try {
      await api.switchKnowledgeBase(kbId);
      // 刷新知识库列表
      await loadKnowledgeBases();
      const kbName = knowledgeBases.find(kb => kb.id === kbId)?.name || kbId;
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: `✅ 已切换到知识库：${kbName}`,
        timestamp: Date.now()
      }]);
    } catch (error) {
      console.error('切换知识库失败:', error);
      alert('切换知识库失败，请重试');
    }
  };

  const handleChat = async () => {
    if (!message.trim()) return;
    
    const userMsg: ChatMessage = {
      role: 'user',
      content: message,
      timestamp: Date.now()
    };
    
    setMessages(prev => [...prev, userMsg]);
    setMessage('');
    setLoading(true);
    
    const activeKb = knowledgeBases.find(kb => kb.is_active);
    const currentKbId = activeKb?.id || 'default';

    try {
      const response = await api.curatorChat({
        message: userMsg.content,
        audience,
        duration_minutes: duration,
        focus: 'business',
        history: messages.map(m => ({ role: m.role, content: m.content })),
        knowledge_base_id: currentKbId
      });
      
      const assistantMsg: ChatMessage = {
        role: 'assistant',
        content: response.data.reply,
        audio_url: response.data.audio_url,
        timestamp: Date.now()
      };
      
      setMessages(prev => [...prev, assistantMsg]);
      
      // 如果有音频返回，自动播放
      if (response.data.audio_url) {
        playResponseAudio(response.data.audio_url);
      }
    } catch (error) {
      console.error('策展对话失败:', error);
      const errorMsg: ChatMessage = {
        role: 'assistant',
        content: '抱歉，对话发生错误，请重试。',
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const playResponseAudio = (url: string) => {
    const fullUrl = url.startsWith('http') ? url : `http://localhost:8000${url}`;
    
    // 如果已经在播放，先停止
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current.src = fullUrl;
    } else {
      const audio = new Audio(fullUrl);
      audioPlayerRef.current = audio;
    }

    audioPlayerRef.current.onplay = () => setIsPlayingAudio(true);
    audioPlayerRef.current.onended = () => setIsPlayingAudio(false);
    audioPlayerRef.current.onpause = () => setIsPlayingAudio(false);
    
    audioPlayerRef.current.play().catch(e => {
      console.error('播放音频失败:', e);
      setIsPlayingAudio(false);
    });
  };

  const stopPlayback = () => {
    if (audioPlayerRef.current) {
      audioPlayerRef.current.pause();
      audioPlayerRef.current.currentTime = 0;
      setIsPlayingAudio(false);
    }
  };

  const startRecording = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      streamRef.current = stream;

      const audioContext = new (window.AudioContext || (window as any).webkitAudioContext)({
        sampleRate: 16000, // 智谱 ASR 推荐 16k
      });
      audioContextRef.current = audioContext;

      const source = audioContext.createMediaStreamSource(stream);
      const processor = audioContext.createScriptProcessor(4096, 1, 1);
      processorRef.current = processor;
      samplesRef.current = [];

      processor.onaudioprocess = (e) => {
        const inputData = e.inputBuffer.getChannelData(0);
        samplesRef.current.push(new Float32Array(inputData));
      };

      source.connect(processor);
      processor.connect(audioContext.destination);

      setIsRecording(true);
    } catch (error) {
      console.error('无法访问麦克风:', error);
      alert('请允许访问麦克风以使用语音功能');
    }
  };

  const stopRecording = () => {
    if (processorRef.current && isRecording) {
      processorRef.current.disconnect();
      if (audioContextRef.current) {
        audioContextRef.current.close();
      }
      if (streamRef.current) {
        streamRef.current.getTracks().forEach(track => track.stop());
      }

      // 合并采样点
      const totalLength = samplesRef.current.reduce((acc, curr) => acc + curr.length, 0);
      const mergedSamples = new Float32Array(totalLength);
      let offset = 0;
      for (const samples of samplesRef.current) {
        mergedSamples.set(samples, offset);
        offset += samples.length;
      }

      // 编码为 WAV
      const audioBlob = encodeWAV(mergedSamples, 16000);
      handleVoiceChat(audioBlob);
      setIsRecording(false);
    }
  };

  const handleVoiceChat = async (audioBlob: Blob) => {
    const activeKb = knowledgeBases.find(kb => kb.is_active);
    const currentKbId = activeKb?.id || 'default';

    setLoading(true);
    try {
      const response = await api.curatorVoiceChat(
        audioBlob, 
        audience, 
        duration, 
        voiceId,
        messages.map(m => ({ role: m.role, content: m.content })),
        currentKbId
      );
      
      // 这里的回复文本通常包含 [你听起来在说：...]
      const replyParts = response.data.reply.split('\n');
      const userPart = replyParts[0].match(/\[你听起来在说：(.+?)\]/);
      const userText = userPart ? userPart[1] : '语音输入';
      const assistantText = userPart ? replyParts.slice(1).join('\n') : response.data.reply;

      const userMsg: ChatMessage = {
        role: 'user',
        content: userText,
        timestamp: Date.now()
      };
      
      const assistantMsg: ChatMessage = {
        role: 'assistant',
        content: assistantText,
        audio_url: response.data.audio_url,
        timestamp: Date.now()
      };
      
      setMessages(prev => [...prev, userMsg, assistantMsg]);
      
      if (response.data.audio_url) {
        playResponseAudio(response.data.audio_url);
      }
    } catch (error) {
      console.error('语音对话失败:', error);
      const errorMsg: ChatMessage = {
        role: 'assistant',
        content: '语音识别或对话失败，请重试。',
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, errorMsg]);
    } finally {
      setLoading(false);
    }
  };

  const handleClearHistory = () => {
    if (window.confirm('确定要清空对话历史吗？')) {
      setMessages([]);
    }
  };

  const handleGenerateScript = async () => {
    if (messages.length === 0) {
      alert('请先通过对话描述您的需求。');
      return;
    }

    setLoading(true);
    try {
      // 汇总整个对话历史作为需求
      const historyText = messages
        .map(m => `${m.role === 'user' ? '用户' : '策划师'}: ${m.content}`)
        .join('\n');

      // 使用当前激活的知识库
      const activeKb = knowledgeBases.find(kb => kb.is_active);
      const currentKbId = activeKb?.id || 'default';
      
      const response = await api.generateScript({
        audience,
        durationMinutes: duration,
        requirement: historyText,
        voiceId: voiceId,
        knowledgeBaseId: currentKbId,
      });
      setScript(response.data);
      
      // 不再在对话中生成详细脚本，而是给出一个简洁的完成提示
      const successMsg: ChatMessage = {
        role: 'assistant',
        content: `✅ 脚本生成完毕！内容已加载至右侧播放器（共 ${response.data.timeline.length} 个讲解节点）。`,
        timestamp: Date.now()
      };
      setMessages(prev => [...prev, successMsg]);
    } catch (error) {
      console.error('生成脚本失败:', error);
      alert('生成脚本失败，请重试');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="curator-panel">
      {/* Loading 遮罩 */}
      {loading && (
        <div className="loading-overlay">
          <div className="loading-spinner">
            <div className="spinner"></div>
            <p>处理中...</p>
          </div>
        </div>
      )}
      
      <h2>🎨 策展配置</h2>
      
      <div className="form-group">
        <label>目标受众</label>
        <select value={audience} onChange={(e) => setAudience(e.target.value)}>
          <option value="技术经理">技术经理</option>
          <option value="产品经理">产品经理</option>
          <option value="投资人">投资人</option>
          <option value="普通客户">普通客户</option>
        </select>
      </div>

      <div className="form-group">
        <label>讲解时长（分钟）</label>
        <input
          type="number"
          min="1"
          max="30"
          value={duration}
          onChange={(e) => setDuration(Number(e.target.value))}
        />
      </div>

      <div className="form-group">
        <label>🎤 语音选择</label>
        <select value={voiceId} onChange={(e) => setVoiceId(e.target.value)}>
          {voices.length > 0 ? (
            voices.map((voice) => (
              <option key={voice.id} value={voice.id}>
                {voice.name}
              </option>
            ))
          ) : (
            <option value="zh-CN-YunxiNeural">云希(男声-沉稳)</option>
          )}
        </select>
      </div>

      <div className="form-group">
        <label>📚 知识库选择</label>
        <select 
          value={knowledgeBases.find(kb => kb.is_active)?.id || 'default'}
          onChange={(e) => handleSwitchKnowledgeBase(e.target.value)}
        >
          {knowledgeBases.map((kb) => (
            <option key={kb.id} value={kb.id}>
              {kb.name} ({typeof kb.total_documents === 'number' ? kb.total_documents : kb.total_documents === '未加载' ? '未加载' : 0} 个分块)
            </option>
          ))}
        </select>
        <div className="kb-hint">
          <span className="kb-tip-icon">ℹ️</span>
          <span className="kb-tip-text">切换知识库后，生成的脚本将使用该知识库的内容</span>
        </div>
      </div>

      <div className="form-group">
        <label>策展需求对话</label>
        <div className="chat-history">
          {messages.length === 0 ? (
            <div className="chat-empty">
              <p>请通过语音或文字描述您的讲解需求，我会为您提供策展建议。</p>
            </div>
          ) : (
            messages.map((msg, idx) => (
              <div key={idx} className={`chat-bubble ${msg.role}`}>
                <div className="bubble-content">{msg.content}</div>
                {msg.audio_url && (
                  <button className="play-mini-btn" onClick={() => playResponseAudio(msg.audio_url!)}>
                    🔊
                  </button>
                )}
              </div>
            ))
          )}
          <div ref={chatEndRef} />
        </div>
      </div>

      <div className="chat-input-area">
        <textarea
          placeholder="描述您的讲解需求，或按住下方麦克风..."
          value={message}
          onChange={(e) => setMessage(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
              e.preventDefault();
              handleChat();
            }
          }}
          rows={2}
        />
        <button className="clear-btn" onClick={handleClearHistory} title="清空对话">
          <FaTrash />
        </button>
      </div>

      <div className="button-group">
        <button 
          onClick={handleChat} 
          disabled={loading || !message.trim()}
          className="chat-btn"
        >
          <FaCommentDots /> {loading ? '对话中...' : '发送'}
        </button>

        <button 
          onMouseDown={startRecording}
          onMouseUp={stopRecording}
          onTouchStart={startRecording}
          onTouchEnd={stopRecording}
          disabled={loading}
          className={`voice-btn ${isRecording ? 'recording' : ''}`}
          title="按住说话"
        >
          {isRecording ? <FaStop /> : <FaMicrophone />}
          {isRecording ? ' 正在聆听...' : ' 按住说话'}
        </button>

        {isPlayingAudio && (
          <button onClick={stopPlayback} className="stop-btn" title="停止播放语音">
            <FaStop /> 停止播放
          </button>
        )}

        <button 
          onClick={handleGenerateScript} 
          disabled={loading || messages.length === 0}
          className="generate-btn highlight"
        >
          <FaMagic /> {loading ? '生成中...' : '确认需求并生成脚本'}
        </button>
      </div>

      <audio ref={audioPlayerRef} style={{ display: 'none' }} />
    </div>
  );
}
