export interface ScriptNode {
  seq_id: number;
  type: string;
  url: string;
  voice_text: string;
  voice_id?: string;
  duration_ms: number;
  hotspots?: any[];
  rag_tags: string[];
}

export interface ScriptMeta {
  title: string;
  target_audience: string;
  estimated_duration: number;
}

export interface Script {
  id: string;
  meta: ScriptMeta;
  timeline: ScriptNode[];
}

export interface CuratorRequest {
  message: string;
  audience: string;
  duration_minutes: number;
  focus: string;
  history?: { role: string; content: string }[];
  knowledge_base_id?: string;
}

export interface CuratorResponse {
  reply: string;
  audio_url?: string;
}

export interface Voice {
  id: string;
  name: string;
  gender: string;
}

export interface KnowledgeBase {
  id: string;
  name: string;
  collection_name?: string;
  total_documents?: number | string;
  uploaded_files?: any[];
  is_active: boolean;
  created_at?: number;
}

export interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
  audio_url?: string;
  timestamp: number;
}

export type PlayerState = 'idle' | 'playing' | 'paused' | 'loading' | 'error';

export interface PlayerStateData {
  state: PlayerState;
  currentPageIndex: number;
  script: Script | null;
  audioElement: HTMLAudioElement | null;
  isPlaying: boolean;
  progress: number;
}
